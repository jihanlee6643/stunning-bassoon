# YouTube Stats (Streamlit)

YouTube URL을 입력하면 공개 영상의 제목, 썸네일, 조회수, 좋아요 수, 댓글 수를 표시합니다.

## Streamlit Community Cloud 배포
1. GitHub에 `app.py`와 `requirements.txt`를 업로드합니다. **API 키는 업로드하지 마세요.**
2. https://share.streamlit.io 에서 GitHub 저장소를 연결하고 `app.py`를 선택합니다.
3. App settings > Secrets에 다음 내용을 입력합니다.

```toml
YOUTUBE_API_KEY = "새로_발급한_API_키"
```

4. YouTube Data API v3가 활성화되어 있는지 확인하고 배포합니다.

참고: Community Cloud 무료 앱은 유휴 시 절전 상태가 될 수 있습니다.
